/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String);
       def dat = new JsonSlurper().parseText(body)
       def builder = new JsonBuilder()
       def stat = "${dat.d.results.UserStatusCode}"
       def check = dat.d.results.ZSitecoreContactUUIDcontent_SDK
       def azure_sys =  dat.d.results.ZSiteLeadRepSystem_SDK.toUpperCase()
       def resultCode  = "${dat.d.results.ResultReasonCode}"
       def resultCodeText = "${dat.d.results.ResultReasonCodeText}"
       
       if(stat == "02"){
           resultCode = ""
           resultCodeText = ""
       }
       
       message.setProperty("ZSystem",azure_sys)
       
        if(check == null || check == ''){
            def  mapProperties = message.getProperties();
            message.setProperty("MakeCall", "no");
        }
             
       builder {
            "contactId" "${dat.d.results.ZSitecoreContactUUIDcontent_SDK}"
            "accountId" "${dat.d.results.ZSitecoreUUIDcontent_SDK}"
            "interactionID"  "${dat.d.results.ZSitecoreLeadUUIDcontent_SDK}"
            "sapLeadId" "${dat.d.results.ID}"
            "reasoncode" resultCode
            "leadReasonDesc" resultCodeText
            "leadStatusId" stat
       }
       
       message.setBody(builder.toPrettyString())
       return message;
}