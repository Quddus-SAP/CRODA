/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body
        def body = message.getBody(String);
        def my_json_obj = new JsonSlurper().parseText(body)
        def my_val = my_json_obj.data.'entity-id';
        def map = message.getProperties();
        message.setProperty("ZObjID", my_val);
        
       return message;
}

def Message pushData(Message message){
    def body = message.getBody(String);
    def dat = new JsonSlurper().parseText(body)
       def getArray = dat.d.results.CustomerOrderBusinessTransactionDocumentReference.find{
           it -> it.TypeCode == "64"
       }
       def leadID = getArray.ID //"${dat.d.results.ZShipTo_County_SDK}"
       def orderstatus  = "${dat.d.results.OrderExternalLifeCycleStatusCode}"
       def cancelstatus = "${dat.d.results.ItemListCancellationStatusCode}"
       def cancelreason = "${dat.d.results.CancellationReasonCodeText}"
       def sys = "${dat.d.results.ZSiteOrderRepSystem_SDK}"
       sys = sys.toUpperCase();
       def map = message.getProperties();
        message.setProperty("ZLeadID", leadID);
        message.setProperty("ZCancelReason", cancelreason);
        message.setProperty("ZCancelStatus", cancelstatus);
        message.setProperty("ZOrderStatus", orderstatus);
        message.setProperty("ZSystem", sys);
        if(sys == null || sys == ''){
            message.setProperty("ZMakeCall", "no"); 
        }
         
        return message;
    
}

def Message buildPayload(Message message){
      def body = message.getBody(String);
      def map = message.getProperties();
       def dat = new JsonSlurper().parseText(body);
       def contactuuid = "${dat.d.results.ZSitecoreContactUUIDcontent_SDK}"
       contactuuid = contactuuid.replace("[","").replace("]","")
       def leaduuid = "${dat.d.results.ZSitecoreLeadUUIDcontent_SDK}"
       leaduuid = leaduuid.replace("[","").replace("]","")
       def leadid = map.get("ZLeadID");
       def orderstatus = map.get("ZOrderStatus");
       def cancelstatus = map.get("ZCancelStatus");
       def cancelreason = map.get("ZCancelReason");
       def builder = new JsonBuilder()
       builder {
            "contactId" contactuuid
            "interactionID"  leaduuid
            "sapLeadId" leadid
            "sampleRequestStatusId" orderstatus
            "sampleRequestCancelId" cancelstatus
            "sampleRequestReasonDesc" cancelreason
           
       }
       
        message.setBody(builder.toPrettyString())
       return message;
    
}