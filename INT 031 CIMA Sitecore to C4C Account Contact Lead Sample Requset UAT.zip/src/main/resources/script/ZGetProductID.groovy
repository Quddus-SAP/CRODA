import com.sap.it.api.mapping.*;
import groovy.json.JsonSlurper
/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String customFunc(String arg1){
            def sr = arg1;
            //def get = new URL("https://my331892.crm.ondemand.com/sap/c4c/odata/cust/v1/zproduct/MaterialCollection?\$search=${sr}&\$select=InternalID").openConnection() as HttpURLConnection
            def get = new URL("https://my331892.crm.ondemand.com/sap/c4c/odata/cust/v1/zproduct/MaterialCollection?\$filter=${sr}&\$select=LocalObjectID").openConnection() as HttpURLConnection
            get.setRequestProperty('Accept', 'Application/json')
            get.setRequestMethod('GET');
            get.setRequestProperty('Authorization','Basic ' + '_DEMO:India@123'.bytes.encodeBase64().toString());
            
            def getRC = get.getResponseCode()
  
            if(getRC.equals(200)) {
                def res = get.getInputStream().getText();
                try{
                def res1 = new JsonSlurper().parseText(res)
               // arg1 = res1.d.results[0].InternalID
                arg1 = res1.d.results[0].LocalObjectID
                }catch(Exception ex){
                   arg1 = arg1; 
                }
            }
            else{
                arg1 = arg1;
            }
                
	return arg1 
}