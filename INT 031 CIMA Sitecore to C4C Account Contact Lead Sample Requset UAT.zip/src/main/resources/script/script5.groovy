/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
        def body = message.getBody(java.io.Reader)
        def xml = new XmlSlurper().parse(body)
        //def aid = xml.CorporateAccount.AccountID.text();
        def aid_o = xml.CorporateAccount.AccountID.text();
        def pi = xml.CorporateAccount.RoleCode.text();
        def srs = xml.CorporateAccount.ZSiteRepSystem_SDK.text();
        if(pi == "BUP002" && srs != ""){
            message.setProperty("ZAllow_Account_Update", "Yes");
        }
        def aid = xml.CorporateAccount.ZCustomerID_SDK.text().replaceFirst("^0+(?!\$)", "")
        if(aid_o != "" && aid == ""){
            aid = aid_o;
        }
        if(aid != ""){
            //def aoid = xml.CorporateAccount.ObjectID.text();
            def aoid_o = xml.CorporateAccount.ObjectID.text();
            def aoid = xml.CorporateAccount.ZCustomerUUIDcontent_SDK.text();
            if(aoid_o != "" && aoid == ""){
                aoid = aoid_o;
            }
            message.setProperty("ZAccount_ID", aid);
            message.setProperty("ZAccount_OID", aoid);
            message.setProperty("ZContactAccountID", "");
            message.setProperty("ZAccount_Method", "PATCH");
        }
        else{
             message.setProperty("ZAccount_Method", "POST");
        }
       
       def body_pay = message.getProperty("ZPayload")
       message.setBody(body_pay)
       return message;
}