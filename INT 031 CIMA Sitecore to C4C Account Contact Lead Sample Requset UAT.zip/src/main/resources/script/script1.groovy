/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

       //setBody
       def body = message.getBody(String);
       
       //Properties 
       def map = message.getProperties();
       def account_name_value = map.get("ZAccount_Name");
       def contact_email_id = map.get("ZContact_Email");
       def ProcessRequestType = map.get("ZProcessRequestType")

       if(account_name_value == "" || account_name_value == " " || account_name_value == null){
       throw new Exception("Account name does not exist");
       }
       
       if(contact_email_id == "" || contact_email_id == " " || contact_email_id == null){
       throw new Exception("Email does not exist");
       } 
       
       if(ProcessRequestType == "LD" || ProcessRequestType == "SR" || ProcessRequestType == "SL"){
           
       }else{
           throw new Exception("Invalid Processing Type");
       }
       /*
          if (ProcessRequestType != "LD"){
              
          }else if(ProcessRequestType != "SR"){
              
          }else if(ProcessRequestType == "SL"){
  
       } else{
           
       
       }*/
           
        def messageLog = messageLogFactory.getMessageLog(message);
        if(messageLog != null){
            messageLog.addAttachmentAsString("input_message.xml", body, "application/xml");
        }
    
       
   
       return message;
}