/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String);
       
       //Properties 
       def map = message.getProperties();
       def ex = map.get("CamelExceptionCaught");
       def account_name_value = map.get("ZAccount_Name");
       def contact_email_id = map.get("ZContact_Email");
       def ProcessRequestType = map.get("ZProcessRequestType");
       if (ex.getClass().getCanonicalName().equals("javax.script.ScriptException")) {
               message.setHeader("CamelHttpResponseCode","406");
               if(account_name_value == "" || account_name_value == " " || account_name_value == null){
                       message.setBody('{"Error_Msg":"Mandatory field missing: Account Name"}');
               }
               
               if(contact_email_id == "" || contact_email_id == " " || contact_email_id == null){
                    message.setBody('{"Error_Msg":"Mandatory field missing: Email"}');
        
               } 
   
             if(ProcessRequestType == "LD" || ProcessRequestType == "SR" || ProcessRequestType == "SL"){
               
                } else{
                     message.setBody('{"Error_Msg":"Invalid Processing Type"}');
                }
                
                if(ProcessRequestType == "" || ProcessRequestType == " " || ProcessRequestType == null){
                message.setBody('{"Error_Msg":"Mandatory field missing: Processing Type"}');
                }    
       }
       
              
        if (ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException")) {
                message.setHeader("CamelHttpResponseCode","406");
                Reader reader = message.getBody(Reader)
                def msg = new XmlSlurper().parse(reader)
                def er_msg = msg.message.text()
                def er_msg1;
                def getMsgInd = er_msg.indexOf("::")
                if(getMsgInd != -1){
                er_msg1 = er_msg.substring(0,getMsgInd).toString()
                }else{
                  er_msg1 = er_msg;
                }
                def builder = new JsonBuilder()
                builder {
                    "Error_Msg" "${er_msg1}"
                }
                
                message.setBody(builder.toPrettyString());
              
        }
     
       return message;
}