/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def map = message.getHeaders();
    def value = map.get("CamelHttpQuery");
    String str1 = "";
    if (value != null) {
      value = value.replaceAll("productcode=", "")
      String[] str;
      str = value.split(',');

      for (String values: str) {
        values = values.replaceAll("%20", "").replaceAll("%0A", "")
        if (values != "") {
          str1 = str1 + "ZExternal_ID_SDK eq '" + values.trim() + "*SAMP' or "
        }
      }

      if (str1 != "") {
        str1 = "(" + str1.substring(0, str1.length() - 3).trim() + ")"
      } else {
          throw new Exception("Product Missing");
        //str1 = "ZExternal_ID_SDK eq '*NO DATA'";
      }
    } else {
        throw new Exception("Product Missing");
      //str1 = "ZExternal_ID_SDK eq '*NO DATA'";
    }

    message.setHeader("CamelHttpQuery", str1);
    return message;
}